﻿using PruebaMVC.Models;

namespace PruebaMVC.Services.Speficification
{
    public interface IArtistaSpecification
    {
        public bool IsValid(VistaGruposArtista elemento);
    }
}
