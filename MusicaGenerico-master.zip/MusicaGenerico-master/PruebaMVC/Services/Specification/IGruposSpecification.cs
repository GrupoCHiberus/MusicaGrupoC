﻿using PruebaMVC.Models;

namespace PruebaMVC.Services.Speficification
{
    public interface IGruposSpecification
    {
        public bool IsValid(VistaGruposArtista elemento);
    }
}
