﻿namespace PruebaMVC.ViewModel
{
    public class ConciertoConGruposcs
    {

        public DateTime? Fecha { get; set; }

        public string? Genero { get; set; }

        public string? Lugar { get; set; }

        public string? Titulo { get; set; }

        public decimal? Precio { get; set; }
        public int? GruposId { get; set; }

        public int? ConciertosId { get; set; }
        public string? Nombre { get; set; }
    }
}
