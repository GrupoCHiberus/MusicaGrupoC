![alt text](https://github.com/AnggeldDAV/MusicaGenerico/blob/master/Diagrama.png)
